Create custom recipes on https://crafting.thedestruc7i0n.ca/ and then paste them in this folder!
